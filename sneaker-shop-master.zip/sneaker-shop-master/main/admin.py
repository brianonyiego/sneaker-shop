# admin.py
from django.contrib import admin
from .models import ShoeType

admin.site.register(ShoeType)

# Register your models here.
